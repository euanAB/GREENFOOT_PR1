import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)



public class Stars extends Characters
{

    public void act()
    {
        
    }

}
